# SHADOW OF THE ZONE — Android prototype

A small original 3D exploration prototype inspired by the atmosphere of the Zone.

## Open in Godot
1. Extract the ZIP archive.
2. In Godot Project Manager choose **Import**.
3. Select the `project.godot` file inside this folder.
4. Open the project.
5. Press **Run Project** (triangle button).

## Controls
- Touch: drag on the left lower area to move.
- Touch: drag on the right side to look around.
- `PDA`: open/close the PDA info panel.
- `ВЗЯТЬ`: collect a nearby glowing artifact.
- Desktop testing: WASD to move; capture the mouse to look around if available.

## Notes
This is a prototype, not a finished commercial game. It uses procedural primitive geometry and original placeholder scenery. It does not contain original S.T.A.L.K.E.R. assets.
