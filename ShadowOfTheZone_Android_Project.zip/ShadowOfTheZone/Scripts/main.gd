extends Node3D

# SHADOW OF THE ZONE — playable mobile exploration prototype.
# Controls: left virtual stick = move, drag right side = look, PDA = map/info.

var player: CharacterBody3D
var camera: Camera3D
var pitch := 0.0
var yaw := 0.0
var move_touch := -1
var look_touch := -1
var move_origin := Vector2.ZERO
var move_vector := Vector2.ZERO
var artifacts := 0
var pda_open := false
var status_label: Label
var pda_panel: Panel
var pda_label: Label
var joystick_base: ColorRect
var joystick_knob: ColorRect
var screen_size := Vector2.ZERO
var interact_hint := ""

const WALK_SPEED := 4.2
const LOOK_SENS := 0.004
const JOY_RADIUS := 76.0

func _ready() -> void:
    screen_size = get_viewport().get_visible_rect().size
    _make_environment()
    _make_world()
    _make_player()
    _make_hud()
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _make_environment() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.12, 0.17, 0.19)
    sky_mat.sky_horizon_color = Color(0.38, 0.40, 0.36)
    sky_mat.ground_bottom_color = Color(0.10, 0.12, 0.10)
    sky_mat.ground_horizon_color = Color(0.28, 0.29, 0.25)
    sky_mat.sun_angle_max = 12.0
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.48, 0.52, 0.48)
    env.ambient_light_energy = 0.65
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_light_color = Color(0.48, 0.51, 0.47)
    env.fog_density = 0.012
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-42, -28, 0)
    sun.light_energy = 0.55
    sun.shadow_enabled = true
    add_child(sun)

func _material(color: Color, roughness := 1.0, emission := Color.BLACK) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = roughness
    if emission != Color.BLACK:
        mat.emission_enabled = true
        mat.emission = emission
        mat.emission_energy_multiplier = 1.5
    return mat

func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material, collision := true) -> MeshInstance3D:
    var body := StaticBody3D.new() if collision else Node3D.new()
    body.position = pos
    parent.add_child(body)
    var mesh := MeshInstance3D.new()
    var box_mesh := BoxMesh.new()
    box_mesh.size = size
    mesh.mesh = box_mesh
    mesh.material_override = mat
    body.add_child(mesh)
    if collision:
        var shape := CollisionShape3D.new()
        var box_shape := BoxShape3D.new()
        box_shape.size = size
        shape.shape = box_shape
        body.add_child(shape)
    return mesh

func _make_world() -> void:
    var ground_mat := _material(Color(0.20, 0.23, 0.18))
    _box(self, Vector3(0, -0.55, 0), Vector3(180, 1, 180), ground_mat)

    # Worn dirt road
    _box(self, Vector3(0, -0.035, -8), Vector3(9, 0.08, 115), _material(Color(0.30, 0.29, 0.23)), false)

    # Abandoned village buildings
    _make_house(Vector3(-12, 0, -10), 0.15)
    _make_house(Vector3(13, 0, -23), -0.22)
    _make_house(Vector3(-17, 0, -39), 0.3)
    _make_house(Vector3(17, 0, -52), -0.1)
    _make_house(Vector3(-5, 0, -69), 0.05)

    # Trees around the village and along the road
    for i in range(52):
        var x := randf_range(-58, 58)
        var z := randf_range(-82, 32)
        if abs(x) < 7.0 and z < 8.0:
            continue
        _make_tree(Vector3(x, 0, z), randf_range(0.75, 1.35))

    # Broken fence fragments
    var fence_mat := _material(Color(0.22, 0.20, 0.16))
    for i in range(9):
        _box(self, Vector3(-7.5 + i * 1.4, 0.55, -16), Vector3(0.16, 1.1, 0.16), fence_mat)
    _box(self, Vector3(-2.0, 0.65, -16), Vector3(13, 0.12, 0.12), fence_mat)

    # Radioactive anomaly clearing and collectible artifacts
    _make_anomaly(Vector3(5, 0.05, -34))
    _make_artifact(Vector3(5, 0.85, -34))
    _make_anomaly(Vector3(-21, 0.05, -58))
    _make_artifact(Vector3(-21, 0.85, -58))

    # Distant silhouettes
    for i in range(7):
        var tower := _box(self, Vector3(-42 + i * 14, 5.0, -90), Vector3(1.2, 10, 1.2), _material(Color(0.17, 0.19, 0.17)))
        tower.rotation_degrees.y = randf_range(-10, 10)

func _make_house(pos: Vector3, rot: float) -> void:
    var house := Node3D.new()
    house.position = pos
    house.rotation.y = rot
    add_child(house)
    var wall := _material(Color(0.30, 0.29, 0.25))
    var dark := _material(Color(0.12, 0.13, 0.12))
    var roof := _material(Color(0.19, 0.18, 0.15))
    _box(house, Vector3(0, 1.45, 0), Vector3(7, 2.9, 6), wall)
    _box(house, Vector3(0, 3.15, 0), Vector3(7.8, 0.35, 6.8), roof)
    # Dark window recesses and doorway are visual details
    _box(house, Vector3(-1.8, 1.75, -3.03), Vector3(1.25, 1.0, 0.06), dark, false)
    _box(house, Vector3(1.8, 1.75, -3.03), Vector3(1.25, 1.0, 0.06), dark, false)
    _box(house, Vector3(0, 1.0, 3.04), Vector3(1.25, 2.0, 0.06), dark, false)
    # One fallen roof beam
    var beam := _box(house, Vector3(2.5, 2.7, 0.2), Vector3(5.0, 0.18, 0.22), roof, false)
    beam.rotation_degrees.z = 18

func _make_tree(pos: Vector3, scale_factor: float) -> void:
    var tree := Node3D.new()
    tree.position = pos
    tree.scale = Vector3.ONE * scale_factor
    add_child(tree)
    var trunk := MeshInstance3D.new()
    var cylinder := CylinderMesh.new()
    cylinder.top_radius = 0.18
    cylinder.bottom_radius = 0.32
    cylinder.height = 3.4
    trunk.mesh = cylinder
    trunk.position.y = 1.7
    trunk.material_override = _material(Color(0.20, 0.17, 0.13))
    tree.add_child(trunk)
    var crown := MeshInstance3D.new()
    var cone := ConeMesh.new()
    cone.radius = 2.0
    cone.height = 5.0
    crown.mesh = cone
    crown.position.y = 5.0
    crown.material_override = _material(Color(0.15, 0.22, 0.17))
    tree.add_child(crown)

func _make_anomaly(pos: Vector3) -> void:
    var ring := MeshInstance3D.new()
    var torus := TorusMesh.new()
    torus.inner_radius = 1.15
    torus.outer_radius = 1.45
    ring.mesh = torus
    ring.position = pos
    ring.rotation_degrees.x = 90
    ring.material_override = _material(Color(0.32, 0.62, 0.54, 0.7), 0.25, Color(0.12, 0.45, 0.34))
    add_child(ring)
    var glow := OmniLight3D.new()
    glow.position = pos + Vector3(0, 1.1, 0)
    glow.light_color = Color(0.25, 0.9, 0.65)
    glow.light_energy = 1.1
    glow.omni_range = 5
    add_child(glow)

func _make_artifact(pos: Vector3) -> void:
    var item := Area3D.new()
    item.position = pos
    item.set_meta("artifact", true)
    add_child(item)
    var shape := CollisionShape3D.new()
    var sphere_shape := SphereShape3D.new()
    sphere_shape.radius = 1.4
    shape.shape = sphere_shape
    item.add_child(shape)
    var mesh := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.28
    sphere.height = 0.56
    mesh.mesh = sphere
    mesh.material_override = _material(Color(0.25, 0.95, 0.66), 0.18, Color(0.1, 0.9, 0.48))
    item.add_child(mesh)
    var light := OmniLight3D.new()
    light.light_color = Color(0.15, 1.0, 0.55)
    light.light_energy = 1.3
    light.omni_range = 4
    item.add_child(light)

func _make_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.position = Vector3(0, 1.1, 5)
    add_child(player)
    var capsule := CollisionShape3D.new()
    var capsule_shape := CapsuleShape3D.new()
    capsule_shape.radius = 0.38
    capsule_shape.height = 1.8
    capsule.shape = capsule_shape
    player.add_child(capsule)
    camera = Camera3D.new()
    camera.position = Vector3(0, 0.58, 0)
    camera.current = true
    player.add_child(camera)

func _make_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(root)

    var title := Label.new()
    title.text = "SHADOW OF THE ZONE   •   CORDON"
    title.position = Vector2(22, 16)
    title.add_theme_font_size_override("font_size", 20)
    title.add_theme_color_override("font_color", Color(0.83, 0.87, 0.78))
    root.add_child(title)

    status_label = Label.new()
    status_label.text = "АРТЕФАКТЫ: 0   |   ЗДОРОВЬЕ: 100"
    status_label.position = Vector2(22, 48)
    status_label.add_theme_font_size_override("font_size", 16)
    status_label.add_theme_color_override("font_color", Color(0.55, 0.85, 0.66))
    root.add_child(status_label)

    joystick_base = ColorRect.new()
    joystick_base.color = Color(0.65, 0.72, 0.68, 0.20)
    joystick_base.size = Vector2(150, 150)
    joystick_base.position = Vector2(30, screen_size.y - 180)
    joystick_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(joystick_base)
    joystick_knob = ColorRect.new()
    joystick_knob.color = Color(0.82, 0.88, 0.82, 0.48)
    joystick_knob.size = Vector2(58, 58)
    joystick_knob.position = joystick_base.position + Vector2(46, 46)
    joystick_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(joystick_knob)

    var pda_button := Button.new()
    pda_button.text = "PDA"
    pda_button.size = Vector2(100, 54)
    pda_button.position = Vector2(screen_size.x - 122, 22)
    pda_button.add_theme_font_size_override("font_size", 20)
    pda_button.pressed.connect(_toggle_pda)
    root.add_child(pda_button)

    var collect_button := Button.new()
    collect_button.text = "ВЗЯТЬ"
    collect_button.size = Vector2(112, 58)
    collect_button.position = Vector2(screen_size.x - 136, screen_size.y - 92)
    collect_button.add_theme_font_size_override("font_size", 17)
    collect_button.pressed.connect(_collect_nearby)
    root.add_child(collect_button)

    pda_panel = Panel.new()
    pda_panel.size = Vector2(min(430, screen_size.x - 50), 260)
    pda_panel.position = (screen_size - pda_panel.size) / 2
    pda_panel.visible = false
    root.add_child(pda_panel)
    pda_label = Label.new()
    pda_label.position = Vector2(20, 16)
    pda_label.size = pda_panel.size - Vector2(40, 32)
    pda_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    pda_label.add_theme_font_size_override("font_size", 18)
    pda_label.text = "PDA — ПЕРСОНАЛЬНЫЙ КОМПЬЮТЕР\n\nЛокация: Кордон\nЗадание: исследовать окрестности и найти артефакты.\n\nСобрано артефактов: 0\n\nНажми PDA, чтобы закрыть."
    pda_panel.add_child(pda_label)

func _process(_delta: float) -> void:
    if is_instance_valid(player):
        status_label.text = "АРТЕФАКТЫ: %d   |   ЗДОРОВЬЕ: 100" % artifacts

func _physics_process(delta: float) -> void:
    if player == null or pda_open:
        return
    var keyboard := Vector2.ZERO
    keyboard.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
    keyboard.y = Input.get_action_strength("move_forward") - Input.get_action_strength("move_back")
    var direction := Vector2(move_vector.x, move_vector.y) + keyboard
    direction = direction.limit_length(1.0)
    var forward := -player.global_transform.basis.z
    var right := player.global_transform.basis.x
    var velocity_dir := (right * direction.x + forward * direction.y)
    player.velocity.x = velocity_dir.x * WALK_SPEED
    player.velocity.z = velocity_dir.z * WALK_SPEED
    if not player.is_on_floor():
        player.velocity.y -= 18.0 * delta
    else:
        player.velocity.y = -0.2
    player.move_and_slide()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < screen_size.x * 0.48 and event.position.y > screen_size.y * 0.48:
                move_touch = event.index
                move_origin = event.position
                _update_joystick(event.position)
            elif event.position.x < screen_size.x - 145:
                look_touch = event.index
        else:
            if event.index == move_touch:
                move_touch = -1
                move_vector = Vector2.ZERO
                joystick_knob.position = joystick_base.position + Vector2(46, 46)
            if event.index == look_touch:
                look_touch = -1
    elif event is InputEventScreenDrag:
        if event.index == move_touch:
            _update_joystick(event.position)
        elif event.index == look_touch and not pda_open:
            _look(event.relative)
    elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and not pda_open:
        _look(event.relative)
    elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _update_joystick(pos: Vector2) -> void:
    var offset := pos - move_origin
    if offset.length() > JOY_RADIUS:
        offset = offset.normalized() * JOY_RADIUS
    move_vector = Vector2(offset.x / JOY_RADIUS, -offset.y / JOY_RADIUS)
    joystick_knob.position = move_origin + offset - Vector2(29, 29) - joystick_base.position

func _look(relative: Vector2) -> void:
    yaw -= relative.x * LOOK_SENS
    pitch = clamp(pitch - relative.y * LOOK_SENS, -1.25, 1.25)
    player.rotation.y = yaw
    camera.rotation.x = pitch

func _toggle_pda() -> void:
    pda_open = not pda_open
    pda_panel.visible = pda_open
    pda_label.text = "PDA — ПЕРСОНАЛЬНЫЙ КОМПЬЮТЕР\n\nЛокация: Кордон\nЗадание: исследовать окрестности и найти артефакты.\n\nСобрано артефактов: %d\n\nНажми PDA, чтобы закрыть." % artifacts

func _collect_nearby() -> void:
    var nearest: Area3D = null
    var nearest_distance := 3.2
    for child in get_children():
        if child is Area3D and child.has_meta("artifact"):
            var d := player.global_position.distance_to(child.global_position)
            if d < nearest_distance:
                nearest_distance = d
                nearest = child
    if nearest:
        nearest.queue_free()
        artifacts += 1
        status_label.text = "АРТЕФАКТ ПОДОБРАН!   |   ВСЕГО: %d" % artifacts
        if pda_open:
            _toggle_pda()
            _toggle_pda()
